.mousey {
  border-style:solid;
  box-sizing: border-box;
  display:inline-block;
  text-align:center;
}
.scroller {
  border-radius: 50px;
  animation-name: scroll;
  animation-duration: 2.2s;
  animation-timing-function: cubic-bezier(.15,.41,.69,.94);
  animation-iteration-count: infinite;
  display:inline-block;
}
@keyframes scroll {
  0% { opacity: 0; }
  10% { transform: translateY(0); opacity: 1; }
  100% { transform: translateY(15px); opacity: 0;}
}