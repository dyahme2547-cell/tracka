<div class="scroll-downs" style="text-align:{{alignment}};">
  {% if enable_link == "true" %}<a href="{{link}}" {{link_html_attributes|raw}} aria-label="Scroll Down" role="button">{% endif %}	
  <div class="mousey" aria-hidden="true">
    <div class="scroller"></div>
  </div>
  {% if enable_link == "true" %}</a>{% endif %}	
</div>