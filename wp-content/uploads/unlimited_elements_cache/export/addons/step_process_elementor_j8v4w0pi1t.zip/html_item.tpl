<div class="ue-step-item ue-item {{item.item_repeater_class}}">
    <div class="ue-item-highlight">
      
      <div class="ue-step-item-line"></div>
      <div class="ue-step-item-gap"></div>
      <div class="ue-step-icon {{graphic_element_animation}}">
        {% if item.graphic_element == "icon" %}<span class="ue-icon">{{item.icon_html|raw}}</span>{% endif %}
        {% if item.graphic_element == "text" %}<span class="ue-graphic-text">{{item.graphic_element_text|raw}}</span>{% endif %}
        {% if item.graphic_element == "image" %}<span class="ue-graphic-image"><img src="{{item.graphic_element_image}}" {{item.graphic_element_image_alt}}></span>{% endif %}
        
        {% if show_label == "true" %}<div class="ue-step-label">{{item.label|raw}}</div>{% endif %}
      </div>
      <div class="ue-step-item-gap"></div>
      <div class="ue-step-item-line"></div>
      
    </div>
    
    <div class="ue-step-item-spacer"></div>
    
    <div class="ue-step-item-content">  
       {% if show_title == "true" %}<div class="ue-step-item-content-title">{{item.title|raw}}</div>{% endif %}
       {% if show_text == "true" %}<div class="ue-step-item-content-text">{{item.text|raw}}</div>{% endif %}
    </div>
  
  {% if item.enable_link == "true" %}<a class="ue-link" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}></a>{% endif %}
  </div>