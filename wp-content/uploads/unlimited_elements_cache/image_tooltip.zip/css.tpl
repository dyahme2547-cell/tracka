#{{uc_id}}{
  position:relative;
  display:flex;
}
#{{uc_id}} img{
  display:block;
  font-size:0px;
}

#{{uc_id}}-tooltip
{
  font-size:{{font_size}}px;
  text-align:{{text_align}};
  line-height:{{line_height}}em;
  display:block;
}

.tooltip-{{uc_serial}}.tooltipster-sidetip .tooltipster-box{ background: {{tooltip_bg}} !important; border-color: {{tooltip_border_color}} !important;}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-bottom .tooltipster-arrow-background{border-bottom-color:{{tooltip_bg}};}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-left .tooltipster-arrow-background{border-left-color:{{tooltip_bg}};}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-right .tooltipster-arrow-background{border-right-color:{{tooltip_bg}};}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-top .tooltipster-arrow-background{border-top-color:{{tooltip_bg}};}

.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-bottom .tooltipster-arrow-border{border-bottom-color:{{tooltip_border_color}};}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-left .tooltipster-arrow-border{border-left-color:{{tooltip_border_color}};}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-right .tooltipster-arrow-border{border-right-color:{{tooltip_border_color}};}
.tooltip-{{uc_serial}}.tooltipster-sidetip.tooltipster-top .tooltipster-arrow-border{border-top-color:{{tooltip_border_color}};}

.tooltip-{{uc_serial}}.tooltipster-sidetip .tooltipster-content{color:{{tooltip_text_color}} !important;}