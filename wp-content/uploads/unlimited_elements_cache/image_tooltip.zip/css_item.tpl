#{{uc_id}} #{{item.item_id}}
{
  {{item.vertical}}:{{item.vert_place}}%;
  {{item.horizontal}}:{{item.horz_place}}%;
  background:{{item.bg_clr}};
  text-decoration:none;
}

#{{uc_id}} #{{item.item_id}}:before
{
  
    border: 1px solid {{item.ripple_color}};
    border-color: {{item.ripple_color}};
}