{% if (show_link == "true") %}
  <a href="{{link}}" {{link_html_attributes|raw}} id="{{uc_id}}" class="ue-tooltip-img" aria-describedby="tooltip-{{uc_serial}}">
{% endif %}
    
{% if (show_link == "false") %}
  <div id="{{uc_id}}" class="ue-tooltip-img" aria-describedby="tooltip-{{uc_serial}}">
{% endif %}
    
    <img class="tooltip image_tooltip" src="{{image}}" {{image_attributes|ucsafe|raw}}>
    
{% if (show_link == "true") %}
  </a>
{% endif %}
{% if (show_link == "false") %}
  </div>
{% endif %}