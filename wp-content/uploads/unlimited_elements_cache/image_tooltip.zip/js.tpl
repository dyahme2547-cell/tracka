{{ ucfunc("put_docready_start") }}
		
  jQuery('#{{uc_id}} .tooltip').tooltipster({
    theme: 'tooltip-{{uc_serial}}',
    contentAsHTML: true,
    content: jQuery(`<span id="{{uc_id}}-tooltip">{{tooltip_text|e('html_attr')}}</span>`),
    trigger: '{{trigger}}',
    {% if (enable_max_width == "true") %}maxWidth:{{max_width}},{% endif %}
	side: '{{tooltip_position}}'                          
  });
    	
{{ ucfunc("put_docready_end") }}