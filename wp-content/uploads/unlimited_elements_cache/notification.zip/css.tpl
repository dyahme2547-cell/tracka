#{{uc_id}} {
  display: flex;
  position:relative;
}

#{{uc_id}} .ue_content{
  display:flex;
}

#{{uc_id}} .ue_text_content{
  display:flex;
  flex-direction: column;
  justify-content: center;
}

#{{uc_id}} .ue_action{
  display: flex;
  flex-wrap: wrap;
}

#{{uc_id}} .ue_action a{
  height: fit-content;
  min-width: max-content;
}

{% if show_graphic_element == "true" %}
  #{{uc_id}} .ue_graphic_el img{
    width:100%;
    height:100%;
  }

  #{{uc_id}} .ue_graphic_el{
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    overflow:hidden;
    flex-shrink: 0;
  }
{% endif %}

#{{uc_id}} .ue_close_notification{
  position:absolute;
  {{vertical_position}}:{{vertical_push}};
  {{horizontal_position}}:{{horizontal_push}};
  cursor:pointer;
  display:flex;
  align-items: center;
  justify-content:center;   
  margin: 0;
}

{% if enable_cookie == "true" %}
 #{{uc_id}}{
   display:none;
 }
{% endif %}