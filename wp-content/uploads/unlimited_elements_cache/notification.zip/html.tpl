<div id="{{uc_id}}" class="ue_notification {{uc_filtering_addclass}}" {{uc_filtering_attributes}} role="status" aria-live="polite">
  
  {% if show_graphic_element == "true" %}
  <div class="ue_graphic_el">
    {% if icon_source == "icon" %}{{graphic_icon_html|raw}}{% endif %}
    {% if icon_source == "img" %}<img src="{{graphic_image}}" {{graphic_image_attributes|ucsafe|raw}}>{% endif %}
    {% if icon_source == "text" %}<span>{{graphic_text|raw}}</span>{% endif %}
    {% if icon_source == "template" %}<span>{{putElementorTemplate(template_templateid)}}</span>{% endif %}
  </div>
  {% endif %}
  
  <div class="ue_content">
    <div class="ue_text_content">
      {% if show_title == "true" %}<{{title_tag}} class="ue_title">{{notification_title|raw}}</{{title_tag}}>{% endif %}
      {% if show_text == "true" %}<{{text_tag}} class="ue_text">{{text|raw}}</{{text_tag}}>{% endif %}
    </div>
    {% if show_button == "true" %}<div class="ue_action uc-items-wrapper">{{put_items()}}</div>{% endif %}    
  </div>
  
  <button class="ue_close_notification" aria-label="Close Notification">{{close_html|raw}}{% if show_close_button_text == "true" %}<span>{{close_text|raw}}</span>{% endif %}</button>
</div>