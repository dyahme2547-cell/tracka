{{ ucfunc("put_docready_start") }}

  var g_objWidget = jQuery("#{{uc_id}}");
  var g_objClose = g_objWidget.find(".ue_close_notification");   
  var cookie_prefix = "ue_notify_{{current_post.id}}_";
		
  // filter-format cookie name 
  {% if enable_cookie == "true" %}
    var {{uc_id}}_cookieName = "{{cookie_name|e('html_attr')}}";
         {{uc_id}}_cookieName = {{uc_id}}_cookieName.replace(/[^!#$%&'*+\-.^_|~0-9A-Za-z]/g, "_");
  {% endif %}
           
  g_objClose.click(function(){
    g_objWidget.fadeOut(200);

    {% if enable_cookie == "true" %}
      {% if cookie_name is not empty %}
        var ue_expires = new Date();
        ue_expires.setTime(ue_expires.getTime() + ({{cookie_exp_day}} * 24 * 60 * 60 * 1000) + ({{cookie_exp_hour}} * 60 * 60 * 1000) + ({{cookie_exp_minutes}} * 60 * 1000) + ({{cookie_exp_sec}} * 1000));
        document.cookie = cookie_prefix + {{uc_id}}_cookieName +"=true; expires=" + ue_expires.toUTCString() + "; path = '{{current_post.link}}';";
      {% endif %}
    {% endif %}

  });
     
  {% if enable_cookie == "true" %}
    if (!document.cookie.includes(cookie_prefix + {{uc_id}}_cookieName +"=true")) {
      g_objWidget.css({
         "display": "flex"
      });
    }
  {% endif %}    
    	
{{ ucfunc("put_docready_end") }}