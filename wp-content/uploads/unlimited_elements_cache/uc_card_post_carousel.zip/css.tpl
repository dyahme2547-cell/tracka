#{{uc_id}} *{
  box-sizing:border-box;
}

#{{uc_id}}{
  position:relative;
  min-height:1px;
}

#{{uc_id}} .uc_image_carousel_content{
	text-align:{{alignment}};
    display: flex;
     flex-flow: column nowrap;
}

#{{uc_id}} .ue_post_carousel_item{
  overflow:hidden;  
}

#{{uc_id}} .uc_image_carousel_bg {
  background-repeat: no-repeat;
}

#{{uc_id}} .uc_image_carousel_placeholder a{
  width:100%;
}

#{{uc_id}} .uc_image_carousel_bg{
  width:100%;
}

#{{uc_id}} .uc_image_carousel_placeholder{
  overflow:hidden;
}

#{{uc_id}} .ue_post_btn_holder{
  margin-top:auto;
}

#{{uc_id}} .uc_more_btn{
  display:{{button_style}};
  text-align:center;
  text-decoration:none;
} 

.uc_overlay_image_carousel .uc_more_btn{
  text-decoration:none;
  display:inline-block;
}

.uc_overlay_image_carousel .uc_post_title{
  font-size:21px;
  text-decoration:none;
}

#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;
}

#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
}


#{{uc_id}} .owl-dots {
  overflow:hidden;
  display:{{show_dots}} !important;
  text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
  border-radius:50%;
  display:inline-block;
}

{% if transition_easing == "false" %}
	#{{uc_id}} .owl-stage {
      transition-timing-function: linear!important;
    }
{% endif %}

{% if link_complete_item == "true" %}
  #{{uc_id}} a.ue-link-all-item{
    position:absolute;
    top:0;
    right:0;
    bottom:0;
    left:0;
    display:block;
  }
{% endif %}