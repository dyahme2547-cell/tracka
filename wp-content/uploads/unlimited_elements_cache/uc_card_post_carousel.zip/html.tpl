<div class="uc_overlay_image_carousel {{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
   <div class="uc_carousel owl-carousel owl-theme uc-items-wrapper">
   		{{put_items()}}
   </div>	
</div>
{% if show_empty_message == "true" %}
{% if uc_num_items == 0 %}
  <div class="ue-no-posts-found">{{no_posts_found|raw}}</div>
{% endif %}
{% endif %}