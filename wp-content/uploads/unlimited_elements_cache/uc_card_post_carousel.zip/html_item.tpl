{# twig vars #}{##}
{% set customFieldTargetAttr = ucfunc("get_post_custom_field",item.post.id,link_complete_item_target) %}
{# end twig vars #}{##}

<div id="{{item.item_id}}" class="uc_image_carousel_container_holder ue_post_carousel_item ue-{{item.post.category_name}}">
  <div class="uc_image_carousel_placeholder">
    <a href="{{item.post.link}}"><div class="uc_image_carousel_bg" style="background-image:url({% if item.post.image is empty %}{{uc_assets_url}}/no-image.png{% else %}{{item.post.image}}{% endif %}); background-position:center;"></div></a>
  </div>

  <div class="uc_image_carousel_content" >
    {% if show_category == "true" %}<div class="ue_post_category"><a href="{{item.post.category_link}}">{{item.post.category_name}}</a></div>{% endif %}
    {% if show_date == "true" %}<div class="ue_post_date">{{item.post.date|ucdate("d F Y")|raw}}</div>{% endif %}
    {% if show_time_ago == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{time_ago_icon_html|raw}}</span> {{text_before_time_ago|raw}} {{item.post.date|ucdate("time_ago")|raw}}</div>{% endif %}
    {% if show_title == "true" %}<a href="{{item.post.link}}" style="text-decoration:none;"><div class="uc_post_title" style="text-decoration:none;">{{item.post.title|raw}}</div></a>{% endif %}
    {% if show_intro == "true" %}<div class="ue_post_intro">{{item.post.intro_full|truncate(intro_number_of_characters)|raw}}</div>{% endif %}    
    {% if show_button == "true" %}<div class="ue_post_btn_holder"><a class="uc_more_btn ue-dynamic-popup-single {{item.post.dynamic_popup_link_class}}" {{item.post.dynamic_popup_link_attributes|raw}} href="{{item.post.link}}" target="{{open_link_in_new_tab}}">{{read_txt|raw}}</a></div>{% endif %}    
  </div>
  
  {% if link_complete_item == "true" %}<a class="ue-link-all-item {{item.post.dynamic_popup_link_class__full}}" {{item.post.dynamic_popup_link_attributes__full|raw}} target="{% if link_complete_item_open_type != "custom" %}{{link_complete_item_open_type}}{% else %}{{customFieldTargetAttr}}{% endif %}"></a>{% endif %}  
</div>