{{ ucfunc("put_docready_start") }}
  
  var objCarousel = jQuery('#{{uc_id}} .owl-carousel');
  var objWrapper = jQuery('#{{uc_id}}');
  	
			objCarousel.owlCarousel({
                loop: {{loop}},      
                navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],
                nav: {{show_arrows}},
				dots: {{show_dots}},                                    
                autoplay: {{autoplay}},
                rtl: {{rtl}},
                center:{{center}},
                paddingType: "{{stage_padding_type}}",
                autoplayTimeout: {{autoplay_timeout}},
                autoplayHoverPause: {{autoplay_hover_pause}},
                smartSpeed: {{transition_speed}},
                setActiveClassOnMobile:{{active_on_mobile}},
                changeItemOnClick:{{scroll_on_click}},
                shuffle:{{shuffle}},
                mouseDrag:{{mouse_drag}},
                touchDrag:{{touch_drag}},
                mousewheelControl: {{enable_mouse_wheel_control}},
                scrollToHead:{{scroll_to_head}},
                scrollToHeadOffset: {{scroll_to_head_offset}},
                responsive : {
					0 : {
                        margin: {{margin_mobile}},              
						items:{{number_of_items_mobile}},
                        slideBy: {{slides_to_scroll_mobile}},
                        scrollToHeadForceOnMobile: {{scroll_to_head_forced_on_mobile}},   
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding_mobile}},
                        {% endif %}	
                        {% if center == "false" %}
                             dotsEach: {{show_dots_each_x_item_mobile}},
                        {% endif %}
					},
					768 : {
						items:{{number_of_items_tablet}},
                        slideBy: {{slides_to_scroll_tablet}},
                        margin: {{margin_tablet}},            
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding_tablet}},
                        {% endif %}	
                        {% if center == "false" %}
                             dotsEach: {{show_dots_each_x_item_tablet}},
                        {% endif %}	
					},
					980 : {
						items:{{number_of_items}},
                        slideBy: {{slides_to_scroll}},
                        margin: {{margin}},            
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding}},
                        {% endif %}	  
                        {% if center == "false" %} 
                             dotsEach: {{show_dots_each_x_item}},
                        {% endif %}
					}
				}
			});
  
	objWrapper.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){
      	
      	objCarousel.trigger("replace.owl.carousel",htmlItems);
      	objCarousel.trigger("refresh.owl.carousel");
         
    });
  
{{ ucfunc("put_docready_end") }}