{% if apply_opening_animation == 'true' %}

  {% if menu_direction == 'column-reverse' %}

    #{{uc_id}} .{{item.item_repeater_class}} {
      z-index: {{item.item_index}};
      --item-index: {{item.item_index}} - 1; 
      {% if item.item_index == '1' %}
      /* --height: ( var(--container-height) - var(--item-height) - 10 ); */
      	--height: ( var(--container-height) - 5 ); 
      {% else %}
      /* --height: calc( var(--container-height) - ( 10 + 5 * {{item.item_index}} - 1) - ( var(--item-height) * {{item.item_index}} ) );  */
       --height: calc( var(--container-height) -  ( var(--item-height) * var(--item-index ) - var(--item-height) ) - ( 5 * var(--item-index) ) ); 
      {% endif %}
      transform: translateY(calc(var(--height) * 1px));
      transition: transform 600ms calc( ( var(--items-total) - {{item.item_index}} + 1 ) * 100ms) ease-in-out;
    }
	
    #{{uc_id}} .{{item.item_repeater_class}}.ue-active {
      transform: translateY(0px);
      transition: transform 600ms calc( {{item.item_index}} * 100ms) ease-in-out;
    }

    #{{uc_id}} .{{item.item_repeater_class}} .el-floating-chat-item__icon{
      transform: scale(0.5);
      transition: transform 600ms calc( ( var(--items-total) - {{item.item_index}} + 1 ) * 100ms) ease-in-out, background-color 400ms ease-in-out;
    }

    #{{uc_id}} .{{item.item_repeater_class}}.ue-active .el-floating-chat-item__icon{
      transform: scale(1);
      transition: transform 600ms calc( {{item.item_index}} * 100ms) ease-in-out, background-color 400ms ease-in-out;
    }

  {% elseif menu_direction == 'column' %}

    #{{uc_id}} .{{item.item_repeater_class}}.ue-active  {
      transform: translateY(0px);
      transition: transform 600ms calc( ( var(--items-total) - {{item.item_index}} + 1 ) * 100ms) ease-in-out;
    }
    #{{uc_id}} .{{item.item_repeater_class}} {
      
      {% if item.item_index == '1' %}
        z-index: var(--items-total);
        /* transform: translateY(calc( var(--item-height) * {{item.item_index}} * -1px)); */
        transform: translateY(var(--height));
      {% else %}
        z-index: calc( var(--items-total) - ( {{item.item_index}} - 1 ) );
		/* transform: translateY(calc( ( var(--item-height) * {{item.item_index}} + 5 * {{item.item_index}} ) * -1px)); */
		transform: translateY(var(--height));
      {% endif %}
      
      transition: transform 600ms calc( {{item.item_index}} * 100ms) ease-in-out;
    }

    #{{uc_id}} .{{item.item_repeater_class}} .el-floating-chat-item__icon{
      transform: scale(0.5);
      transition: transform 600ms calc( {{item.item_index}} * 100ms) ease-in-out, background-color 400ms ease-in-out;

    }

    #{{uc_id}} .{{item.item_repeater_class}}.ue-active .el-floating-chat-item__icon{
      transform: scale(1);
      transition: transform 600ms calc( ( var(--items-total) - {{item.item_index}} + 1 ) * 100ms) ease-in-out, background-color 400ms ease-in-out;
    }
  {% endif %}

{% endif %}



{% if item.style_type == 'official' and item.channel == 'regular' %}
  #{{item.item_id}} .el-icon-regular
  {
    background-color:#0099e5;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'email' %}
  #{{item.item_id}} .el-icon-email
  {
    background-color:#ff4c4c;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'sms' %}
  #{{item.item_id}} .el-icon-sms
  {
    background-color:#34bf49;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'phone' %}
  #{{item.item_id}} .el-icon-phone
  {
    background-color:#000000;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'whatsapp' %}
  #{{item.item_id}} .el-icon-whatsapp
  {
    background-color:#25d366;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'slack' %}
  #{{item.item_id}} .el-icon-slack
  {
    background-color:#e01563;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'twitter' %}
  #{{item.item_id}} .el-icon-twitter
  {
    background-color:#1da1f2;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'skype' %}
  #{{item.item_id}} .el-icon-skype
  {
    background-color:#00aff0;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'viber' %}
  #{{item.item_id}} .el-icon-viber
  {
    background-color:#59267c;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'facebook' %}
  #{{item.item_id}} .el-icon-facebook
  {
    background-color:#1877f2;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'wechat' %}
  #{{item.item_id}} .el-icon-wechat
  {
    background-color:#7bb32e;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'snapchat' %}
  #{{item.item_id}} .el-icon-snapchat
  {
    background-color:#fffc00;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'line' %}
  #{{item.item_id}} .el-icon-line
  {
    background-color:#00c300;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'telegram' %}
  #{{item.item_id}} .el-icon-telegram
  {
    background-color:#0088cc;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'instagram' %}
  #{{item.item_id}} .el-icon-instagram
  {
    background-color:#e1306c;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'linkedin' %}
  #{{item.item_id}} .el-icon-linkedin
  {
    background-color:#0077b5;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'tiktok' %}
  #{{item.item_id}} .el-icon-tiktok
  {
    background-color:#000000;
    color:white;
  }
{% endif %}

{% if item.style_type == 'official' and item.channel == 'vkontakte' %}
  #{{item.item_id}} .el-icon-tiktok
  {
    background-color:#45668e;
    color:white;
  }
{% endif %}