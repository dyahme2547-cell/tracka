<div id="{{uc_id}}" class="ue-scroll-to {{snap_vertical}} {{snap_horizontal}}">
      <div class="ue-scroll-to-cta {{attention_grabber}}">
          <div class="ue-scroll-to-icon">{{trigger_icon_html|raw}}</div>
          {% if show_text == "true" %}
          <div class="ue-scroll-to-text">{{text|raw}}</div>
          {% endif %}	
      </div>
</div>