jQuery(document).ready(function(){
  
  function showArrow(pixels){
  
     jQuery(window).scroll(function () {
        if (jQuery(this).scrollTop() > pixels) {
           jQuery('#{{uc_id}}').fadeIn(300);
        } else {
           jQuery('#{{uc_id}}').fadeOut(300);
        }
     });
  
  }
  
  {% if position == "fixed" and show_button_after_scrolling_unit == "px" %}
  
  	{% if show_after_scrolling is not empty %} var pixelsToScroll = {{show_after_scrolling}};{% endif %}
    {% if show_after_scrolling is empty %} var pixelsToScroll = 0;{% endif %}
    
    showArrow(pixelsToScroll);
    
  {% endif %}
  
  {% if position == "fixed" and show_button_after_scrolling_unit == "%" %}
  
  	var scrollablePageHeight = jQuery(document).height() - jQuery(window).height();
   	{% if show_after_scrolling_percents is not empty %}var percentsToScroll = {{show_after_scrolling_percents}};  {% endif %}
    {% if show_after_scrolling_percents is empty %}var percentsToScroll = 20;  {% endif %}
  	var pixelsToScroll = scrollablePageHeight * percentsToScroll / 100;
   
    showArrow(pixelsToScroll);
   
  {% endif %}
  
    function disableElementorSectionSnap(){
      jQuery('html, body').css('scroll-snap-type', 'none');
    }
   
    function enableElementorSectionSnap(){
      jQuery('html, body').css('scroll-snap-type', '');
    }
  
    jQuery('#{{uc_id}} .ue-scroll-to-cta').click(function () {
       {% if scroll_to == "top" %}
           disableElementorSectionSnap();
		   jQuery('body,html').animate({
				scrollTop: 0
		   }, {{scroll_animation_duration}}, enableElementorSectionSnap);
       {% endif %}
       {% if scroll_to == "section" %}
           disableElementorSectionSnap();
           jQuery('html, body').animate({
                    scrollTop: jQuery("{{section_id_class}}").offset().top
           }, {{scroll_animation_duration}}, enableElementorSectionSnap);
       {% endif %}
    });
 });